ssh -i encrypts/key.pem -o StrictHostKeyChecking=no ubuntu@52.57.168.242 "touch a"
